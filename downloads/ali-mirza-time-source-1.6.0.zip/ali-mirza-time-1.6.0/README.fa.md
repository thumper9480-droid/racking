# سورس کامل مدیریت زمان علی میرزا — ۱.۶.۰

این بسته سورس کامل همین برنامهٔ وب و اندروید را دارد: HTML، CSS، JavaScript، Java، منابع XML، لوگو، فونت وزیرمتن، آزمون‌های مرورگر و آزمون محاسبهٔ یادآور اندروید. دادهٔ شخصی یا کلید امضای خصوصی داخل بسته نیست.

## اجرای وب

از پوشهٔ اصلی بسته، که پوشهٔ `zaman` در آن قرار دارد، اجرا کنید:

```sh
python3 -m http.server 4173
```

سپس در مرورگر همان دستگاه نشانی `http://localhost:4173/zaman/` را باز کنید. برنامهٔ وب به نصب کتابخانه نیاز ندارد. داده‌ها در مرورگر ذخیره می‌شوند؛ برای انتقال از تنظیمات بخش فعالیت‌ها پشتیبان JSON بگیرید و در نسخهٔ مقصد بازیابی کنید. لوگو در `zaman/logo.png` است.

## ساخت APK

نیازمندی‌ها: Bash، Python 3، ابزار zip، JDK 21، Android SDK Platform 35 و Android Build Tools 35.0.0. مقدار مسیر ابزارها را مطابق محل نصب خود تعیین کنید:

```sh
export JAVA_HOME=/path/to/jdk-21
export PATH="$JAVA_HOME/bin:$PATH"
export ANDROID_SDK_ROOT=/path/to/android-sdk
export ANDROID_BUILD_TOOLS="$ANDROID_SDK_ROOT/build-tools/35.0.0"
export ZAMAN_SIGNING_DIR=/private/path/to/signing
bash zaman/android/build.sh
```

خروجی `zaman/android/build/zaman-1.6.0.apk` است. اسکریپت امضا و هم‌ترازی فایل را هم بررسی می‌کند. اگر در پوشهٔ امضا کلیدی نباشد، کلید توسعهٔ تازه ایجاد می‌شود. آن را خصوصی نگه دارید؛ کلید تازه نمی‌تواند روی نسخهٔ منتشرشدهٔ قبلی نصب شود. APK همراه لینک انتشار با همان کلید نسخه‌های قبلی ساخته شده و به‌عنوان به‌روزرسانی قابل نصب است. شناسهٔ بسته `ir.zaman.app` و حداقل اندروید ۸ است.

## آزمون‌ها

با Node.js و Chromium نصب‌شده، از پوشهٔ اصلی بسته:

```sh
npm install --no-save --package-lock=false playwright
node zaman/tests/enhancements.cjs
node zaman/tests/reports.cjs
node zaman/tests/native-settings.cjs
node zaman/tests/final-dashboard.cjs
node zaman/tests/project-independent.cjs
node zaman/tests/project-workflow.cjs
node zaman/tests/android-bridge.cjs
```

آزمون‌ها وب‌سرور پورت ۴۱۷۳ و Chromium در `/usr/bin/chromium` را انتظار دارند؛ اگر مرورگر جای دیگری است، `executablePath` را در فایل‌های آزمون مطابق محیط خود تنظیم کنید. آزمون‌های دیگر هم در پوشهٔ `zaman/tests` هستند. راهنمای بیشتر اندروید و آزمون JVM یادآورها در `zaman/android/README.md` قرار دارد.

در مرورگر برای زنگ صفحه باید باز و دستگاه فعال باشد. APK زنگ بومی اندروید دارد و به مجوز اعلان/زنگ دقیق وابسته است. ساخت و امضای APK و آزمون رابط بررسی شده‌اند؛ اجرای زنگ در پس‌زمینه، هنگام قفل و پس از راه‌اندازی مجدد هنوز روی گوشی واقعی بررسی نشده است.


## راهنمای کاربری و انتشار به‌روزرسانی

`help.html` و `user-guide.pdf` همراه تصاویر واقعیِ دادهٔ نمونه در `guide-assets` هستند. برای ساخت دوبارهٔ تصاویر و PDF، وب‌سرور پورت۴۱۷۳ را اجرا و `node zaman/scripts/generate-guide.cjs` را از پوشهٔ اصلی اجرا کنید. این اسکریپت هم به Node.js، Playwright و Chromium نیاز دارد.

برای انتشار بعدی، نسخه و versionCode را در build.sh و enhancements.js و کوئری‌های HTML بالا ببرید، APK را با همان کلید بسازید، سپس sha256sum آن را در release.json همراه لینک معتبر مخزن وارد کنید. APK باید قبل از فعال‌شدن فایل release.json در لینک قابل دانلود باشد. میزبانی استاتیک GitHub Pages برای این قابلیت کافی است؛ سرور حساب یا پرداخت وجود ندارد. نصب نهایی همواره با تأیید گوشی انجام می‌شود.

یادبود۳۰روزه یک تأیید محلی برای «علی میرزا نقدی پور» است. شمارش از اولین اجرای نسخه آغاز می‌شود؛ پس از۳۰روز و در هر تکرار، تا زدن «فرستادم / خواندم» کار اصلی برنامه باز نمی‌شود. پاک‌کردن داده‌ها آن را بازنشانی می‌کند؛ این سازوکار مجوز تجاری یا محافظ ضد‌دستکاری نیست. صدای یادآور/تایمر در تنظیمات اندروید جدا انتخاب می‌شود و جزو پشتیبان دادهٔ JSON نیست.
